import { useState, useEffect } from 'react';
import Header from './Header.jsx'; 
import './OrdenesAdmin.css';
const OrdenesAdmin = () => {
  const [stats, setStats] = useState({
    hoy: 1,
    semana: 2,
    completados: 3,
    pendientes: 3
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState(null);

  useEffect(() => {
    // Animación de contadores
    animateValue('stat-hoy', 0, stats.hoy, 800);
    animateValue('stat-semana', 0, stats.semana, 1000);
    animateValue('stat-completados', 0, stats.completados, 1200);
    animateValue('stat-pendientes', 0, stats.pendientes, 1400);
  }, []);

  const animateValue = (id, start, end, duration) => {
    const element = document.getElementById(id);
    if (!element) return;
    
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    let current = start;
    
    const timer = setInterval(() => {
      current += increment;
      element.textContent = current;
      if (current === end) {
        clearInterval(timer);
      }
    }, stepTime);
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const filterOrders = (category) => {
    setActiveFilter(category);
    
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
      section.style.display = 'none';
    });
    
    if (category === 'hoy') {
      document.getElementById('section-hoy').style.display = 'block';
    } else if (category === 'semana') {
      document.getElementById('section-semana').style.display = 'block';
    } else if (category === 'completados') {
      document.getElementById('section-completados').style.display = 'block';
    } else if (category === 'pendientes') {
      document.getElementById('section-hoy').style.display = 'block';
      document.getElementById('section-semana').style.display = 'block';
    }

    setTimeout(() => {
      window.scrollTo({
        top: 400,
        behavior: 'smooth'
      });
    }, 100);
  };

  return (
    <div>
      <Header userType="admin" />
      
      <div className="container">
        <div className="search-container">
          <input 
            type="text" 
            className="search-box" 
            placeholder="🔍 Buscar Órdenes" 
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>

        <h1 className="page-title">Órdenes</h1>

        <div className="stats-grid">
          <div className="stat-card" onClick={() => filterOrders('hoy')}>
            <div className="stat-number" id="stat-hoy">0</div>
            <div className="stat-label">Servicios de hoy</div>
          </div>
          <div className="stat-card" onClick={() => filterOrders('semana')}>
            <div className="stat-number" id="stat-semana">0</div>
            <div className="stat-label">Esta semana</div>
          </div>
          <div className="stat-card" onClick={() => filterOrders('completados')}>
            <div className="stat-number" id="stat-completados">0</div>
            <div className="stat-label">Completados</div>
          </div>
          <div className="stat-card" onClick={() => filterOrders('pendientes')}>
            <div className="stat-number" id="stat-pendientes">0</div>
            <div className="stat-label">Pendientes</div>
          </div>
        </div>

        {/* Servicios de Hoy */}
        <div className="section" id="section-hoy">
          <h2 className="section-title">Servicios de hoy</h2>
          <div className="orders-grid">
            <div className="order-card" style={{animationDelay: '0.1s'}}>
              <div className="order-header">
                <div className="client-name">William Lozano</div>
                <div className="priority-badge priority-alta">Alta</div>
              </div>
              <div className="service-name">Lavado de sillas</div>
              <div className="status-bar status-pendiente">Pendiente</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-07-19</div>
                <div><strong>Dirección:</strong> Calle 22 #6-30 compartir</div>
                <div><strong>Documento:</strong> 3175311324</div>
                <div><strong>Email:</strong> William.Lozano@gmail.com</div>
              </div>
            </div>
          </div>
        </div>

        {/* Servicios de Esta Semana */}
        <div className="section" id="section-semana">
          <h2 className="section-title">Servicios de esta semana</h2>
          <div className="orders-grid">
            <div className="order-card" style={{animationDelay: '0.2s'}}>
              <div className="order-header">
                <div className="client-name">William Lozano</div>
                <div className="priority-badge priority-alta">Alta</div>
              </div>
              <div className="service-name">Lavado de sillas</div>
              <div className="status-bar status-pendiente">Pendiente</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-07-19</div>
                <div><strong>Dirección:</strong> Calle 22 #6-30 compartir</div>
                <div><strong>Documento:</strong> 3175311324</div>
                <div><strong>Email:</strong> William.Lozano@gmail.com</div>
              </div>
            </div>

            <div className="order-card" style={{animationDelay: '0.3s'}}>
              <div className="order-header">
                <div className="client-name">Keurys Lopez Montes</div>
                <div className="priority-badge priority-media">Media</div>
              </div>
              <div className="service-name">Lavado sofás</div>
              <div className="status-bar status-pendiente">Pendiente</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-07-19</div>
                <div><strong>Dirección:</strong> Calle 22 #6-30 compartir</div>
                <div><strong>Documento:</strong> 3175311324</div>
                <div><strong>Email:</strong> William.Lozano@gmail.com</div>
              </div>
            </div>
          </div>
        </div>

        {/* Servicios Completados */}
        <div className="section" id="section-completados">
          <h2 className="section-title">Servicios completados</h2>
          <div className="orders-grid">
            <div className="order-card" style={{animationDelay: '0.4s'}}>
              <div className="order-header">
                <div className="client-name">Yeny Paola Quiroga</div>
              </div>
              <div className="service-name">Lavado de colchones</div>
              <div className="status-bar status-finalizada">Finalizada</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-07-17</div>
                <div><strong>Dirección:</strong> Calle 22 #6-30 compartir</div>
                <div><strong>Documento:</strong> 3175311324</div>
                <div><strong>Email:</strong> William.Lozano@gmail.com</div>
              </div>
              <div className="observations">
                <strong>Observaciones:</strong>
                Limpieza profunda, colchón seco
              </div>
            </div>

            <div className="order-card" style={{animationDelay: '0.5s'}}>
              <div className="order-header">
                <div className="client-name">Maria Daza Rodriguez</div>
              </div>
              <div className="service-name">Lavado de sillas</div>
              <div className="status-bar status-finalizada">Finalizada</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-07-05</div>
                <div><strong>Dirección:</strong> Calle 22 #6-30 compartir</div>
                <div><strong>Documento:</strong> 3175311324</div>
                <div><strong>Email:</strong> William.Lozano@gmail.com</div>
              </div>
              <div className="observations">
                <strong>Observaciones:</strong>
                Revisión final, todo en orden
              </div>
            </div>

            <div className="order-card" style={{animationDelay: '0.6s'}}>
              <div className="order-header">
                <div className="client-name">Carlos Pérez</div>
              </div>
              <div className="service-name">Lavado de alfombras</div>
              <div className="status-bar status-finalizada">Finalizada</div>
              <div className="order-details">
                <div><strong>Fecha:</strong> 2025-06-28</div>
                <div><strong>Dirección:</strong> Calle 45 #12-20</div>
                <div><strong>Documento:</strong> 1234567890</div>
                <div><strong>Email:</strong> carlos.perez@gmail.com</div>
              </div>
              <div className="observations">
                <strong>Observaciones:</strong>
                Cliente muy satisfecho con el servicio
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrdenesAdmin;