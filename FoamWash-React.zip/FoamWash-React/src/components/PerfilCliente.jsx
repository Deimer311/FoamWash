import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from "./Header.jsx";
import './PerfilCliente.css';

const PerfilCliente = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const cards = document.querySelectorAll('.detail-card');
    cards.forEach((card, index) => {
      card.style.animation = `fadeIn 0.6s ease-out ${index * 0.1}s forwards`;
      card.style.opacity = '0';
    });
  }, []);

  const handleEditProfile = () => {
    navigate('/perfil-cliente-editar');
  };

  return (
    <div>
      <Header userType="cliente" />
      
      <div className="main-content">
        <div className="profile-container">
          {/* Sidebar del perfil */}
          <div className="profile-sidebar">
            <div className="profile-photo">👤</div>
            <div className="profile-name">Romaria González</div>
            <div className="profile-role">Cliente</div>
            
            <div className="profile-stats">
              <div className="stat-item">
                <div className="stat-number">12</div>
                <div className="stat-label">Servicios</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">8</div>
                <div className="stat-label">Completados</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">3</div>
                <div className="stat-label">Pendientes</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">4.9</div>
                <div className="stat-label">Calificación</div>
              </div>
            </div>

            <button className="edit-profile-btn" onClick={handleEditProfile}>
              Editar Perfil
            </button>
          </div>

          {/* Detalles del perfil */}
          <div className="right-panel">
            <div className="profile-details">
              {/* Información Personal */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">👤</span>
                  Información Personal
                </h2>
                <div className="info-grid">
                  <div className="info-item">
                    <span className="info-label">Nombre Completo</span>
                    <div className="info-value">Romaria González Jiménez</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Tipo de Identificación</span>
                    <div className="info-value">Cédula de Ciudadanía</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Número de Documento</span>
                    <div className="info-value">1.234.567.890</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Fecha de Nacimiento</span>
                    <div className="info-value">15 de Mayo, 1990</div>
                  </div>
                </div>
              </div>

              {/* Información de Contacto */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">📧</span>
                  Información de Contacto
                </h2>
                <div className="info-grid">
                  <div className="info-item">
                    <span className="info-label">Correo Electrónico</span>
                    <div className="info-value">romariagonzalezj@gmail.com</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Teléfono</span>
                    <div className="info-value">+57 310 123 4567</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Dirección</span>
                    <div className="info-value">Calle 123 #45-67, Soacha</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Ciudad</span>
                    <div className="info-value">Soacha, Cundinamarca</div>
                  </div>
                </div>
              </div>

              {/* Actividad Reciente */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">📋</span>
                  Actividad Reciente
                </h2>
                <div className="activity-list">
                  <div className="activity-item">
                    <div className="activity-icon">🛋️</div>
                    <div className="activity-content">
                      <div className="activity-title">Lavado de Sofá de 3 Puestos</div>
                      <div className="activity-date">5 de Noviembre, 2025</div>
                    </div>
                    <span className="activity-status status-completed">Completado</span>
                  </div>
                  <div className="activity-item">
                    <div className="activity-icon">🛏️</div>
                    <div className="activity-content">
                      <div className="activity-title">Lavado de Colchón Queen Size</div>
                      <div className="activity-date">28 de Octubre, 2025</div>
                    </div>
                    <span className="activity-status status-pending">Pendiente</span>
                  </div>
                  <div className="activity-item">
                    <div className="activity-icon">💺</div>
                    <div className="activity-content">
                      <div className="activity-title">Limpieza de 6 Sillas de Comedor</div>
                      <div className="activity-date">15 de Octubre, 2025</div>
                    </div>
                    <span className="activity-status status-completed">Completado</span>
                  </div>
                  <div className="activity-item">
                    <div className="activity-icon">🛋️</div>
                    <div className="activity-content">
                      <div className="activity-title">Lavado de Sofá Esquinero</div>
                      <div className="activity-date">3 de Octubre, 2025</div>
                    </div>
                    <span className="activity-status status-cancelled">Cancelado</span>
                  </div>
                </div>
              </div>

              {/* Preferencias */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">⚙️</span>
                  Preferencias
                </h2>
                <div className="info-grid">
                  <div className="info-item">
                    <span className="info-label">Método de Pago Preferido</span>
                    <div className="info-value">Tarjeta de Crédito</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Horario Preferido</span>
                    <div className="info-value">Mañanas (8:00 AM - 12:00 PM)</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Notificaciones</span>
                    <div className="info-value">Email y SMS</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Miembro desde</span>
                    <div className="info-value">Enero 2024</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerfilCliente;