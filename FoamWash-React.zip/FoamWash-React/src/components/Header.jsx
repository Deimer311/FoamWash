import { Link } from 'react-router-dom';
import './Header.css';

const Header = ({ userType = 'admin', userEmail = '' }) => {
  const handleLogout = (e) => {
    e.preventDefault();
    if (window.confirm('¿Estás seguro de que deseas cerrar sesión?')) {
      // Lógica de logout
      window.location.href = './login.html';
    }
  };

  const renderNavLinks = () => {
    if (userType === 'admin') {
      return (
        <>
          <Link to="/" className="nav-link">Hogar</Link>
          <Link to="/ordenes-admin" className="nav-link">Ordenes</Link>
          <Link to="#" className="nav-link">Usuarios</Link>
          <Link to="#" className="nav-link">Servicios</Link>
          <Link to="#" className="nav-link">Reportes</Link>
          <Link to="/perfil-admin" className="nav-link" style={{color: 'rgb(133, 198, 255)'}}>Perfil</Link>
        </>
      );
    } else if (userType === 'empleado') {
      return (
        <>
          <Link to="/" className="nav-link">Hogar</Link>
          <Link to="/ordenes-empleado" className="nav-link">Ordenes</Link>
          <Link to="/perfil-trabajador" className="nav-link" style={{color: 'rgb(133, 198, 255)'}}>Perfil</Link>
          <a href="#" className="nav-link btn-salir" onClick={handleLogout}>Cerrar Sesión</a>
        </>
      );
    } else if (userType === 'cliente') {
      return (
        <>
          <Link to="#" className="nav-link">Hogar</Link>
          <Link to="./cotizar_cliente.html" className="nav-link">Cotización</Link>
          <Link to="./servicios_cliente.html" className="nav-link">Agendar</Link>
          <Link to="/perfil-cliente" className="nav-link" style={{color: 'rgb(133, 198, 255)'}}>Perfil</Link>
          <a href="#" className="nav-link btn-salir" onClick={handleLogout}>Cerrar Sesión</a>
        </>
      );
    }
  };

  return (
    <header className="header-banner">
      <img src="/img/ima9.jpg" alt="Fondo encabezado" className="fondo" />
      <h1 className="logo-header">FoamWash</h1>
      <nav className="nav-bar">
        {renderNavLinks()}
      </nav>
    </header>
  );
};

export default Header;