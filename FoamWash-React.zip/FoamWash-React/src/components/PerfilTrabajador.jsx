// ...existing code...
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from "./Header.jsx";
import './PerfilTrabajador.css';

const PerfilTrabajador = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const cards = document.querySelectorAll('.detail-card');
    cards.forEach((card, index) => {
      card.style.animation = `fadeIn 0.6s ease-out ${index * 0.1}s forwards`;
      card.style.opacity = '0';
    });
  }, []);

  const handleEditProfile = () => {
    navigate('/perfil-trabajador-editar');
  };

  return (
    <div>
      <Header userType="empleado" />
      
      <div className="main-content">
        <div className="profile-container">
          {/* Sidebar del perfil */}
          <div className="profile-sidebar">
            <div className="profile-photo">👤</div>
            <div className="profile-name">Carlos Martínez</div>
            <div className="profile-role">Empleado</div>
            <div className="availability-badge">
              <span className="status-dot"></span>
              <span>Disponible</span>
            </div>
            
            <div className="profile-stats">
              <div className="stat-item">
                <div className="stat-number">156</div>
                <div className="stat-label">Servicios</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">4.8</div>
                <div className="stat-label">Calificación</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">98%</div>
                <div className="stat-label">Puntualidad</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">12</div>
                <div className="stat-label">Este Mes</div>
              </div>
            </div>

            <button className="edit-profile-btn" onClick={handleEditProfile}>
              Editar Perfil
            </button>
          </div>

          {/* Detalles del perfil */}
          <div className="right-panel">
            <div className="profile-details">
              {/* Información Personal */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">👤</span>
                  Información Personal
                </h2>
                <div className="info-grid">
                  <div className="info-item">
                    <span className="info-label">Nombre Completo</span>
                    <div className="info-value">Carlos Alberto Martínez López</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Cédula</span>
                    <div className="info-value">80.123.456</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Fecha de Nacimiento</span>
                    <div className="info-value">22 de Marzo, 1988</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Cargo</span>
                    <div className="info-value">Técnico de Limpieza Senior</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Teléfono</span>
                    <div className="info-value">+57 315 987 6543</div>
                  </div>
                  <div className="info-item">
                    <span className="info-label">Fecha de Ingreso</span>
                    <div className="info-value">15 de Enero, 2023</div>
                  </div>
                </div>
              </div>

              {/* Horario de Hoy */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">📅</span>
                  Horario de Hoy
                </h2>
                <div className="schedule-grid">
                  <div className="schedule-item">
                    <div className="schedule-time">
                      <div className="time-icon">🛋️</div>
                      <div className="time-details">
                        <h4>09:00 AM - Lavado de Sofá</h4>
                        <p>Calle 45 #12-34, Cliente: María García</p>
                      </div>
                    </div>
                    <span className="schedule-status status-inprogress">En Curso</span>
                  </div>
                  <div className="schedule-item">
                    <div className="schedule-time">
                      <div className="time-icon">🛏️</div>
                      <div className="time-details">
                        <h4>11:30 AM - Colchón King Size</h4>
                        <p>Cra 78 #89-12, Cliente: Jorge Pérez</p>
                      </div>
                    </div>
                    <span className="schedule-status status-upcoming">Próximo</span>
                  </div>
                  <div className="schedule-item">
                    <div className="schedule-time">
                      <div className="time-icon">💺</div>
                      <div className="time-details">
                        <h4>02:00 PM - 8 Sillas de Comedor</h4>
                        <p>Av. Principal #56-78, Cliente: Ana Rodríguez</p>
                      </div>
                    </div>
                    <span className="schedule-status status-upcoming">Próximo</span>
                  </div>
                </div>
              </div>

              {/* Desempeño */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">📊</span>
                  Desempeño del Mes
                </h2>
                <div className="performance-grid">
                  <div className="performance-card">
                    <div className="performance-icon">⭐</div>
                    <div className="performance-value">4.8</div>
                    <div className="performance-label">Calificación Promedio</div>
                  </div>
                  <div className="performance-card">
                    <div className="performance-icon">✅</div>
                    <div>
                      <div className="performance-value">12</div>
                      <div className="performance-label">Servicios Completados</div>
                    </div>
                  </div>
                  <div className="performance-card">
                    <div className="performance-icon">⏱️</div>
                    <div className="performance-value">98%</div>
                    <div className="performance-label">Puntualidad</div>
                  </div>
                  <div className="performance-card">
                    <div className="performance-icon">💬</div>
                    <div className="performance-value">10</div>
                    <div className="performance-label">Comentarios Positivos</div>
                  </div>
                </div>
              </div>

              {/* Certificaciones */}
              <div className="detail-card">
                <h2 className="card-title">
                  <span className="card-icon">🏆</span>
                  Certificaciones y Capacitaciones
                </h2>
                <div className="certification-list">
                  <div className="certification-item">
                    <span className="cert-icon">📜</span>
                    <div className="cert-info">
                      <h4>Técnicas Avanzadas de Limpieza de Tapicería</h4>
                      <p>Certificado - Vence: Diciembre 2025</p>
                    </div>
                  </div>
                  <div className="certification-item">
                    <span className="cert-icon">🧪</span>
                    <div className="cert-info">
                      <h4>Manejo de Productos Químicos de Limpieza</h4>
                      <p>Certificado - Vence: Marzo 2026</p>
                    </div>
                  </div>
                  <div className="certification-item">
                    <span className="cert-icon">🛡️</span>
                    <div className="cert-info">
                      <h4>Seguridad y Salud en el Trabajo</h4>
                      <p>Certificado - Vence: Junio 2026</p>
                    </div>
                  </div>
                  <div className="certification-item">
                    <span className="cert-icon">⭐</span>
                    <div className="cert-info">
                      <h4>Atención al Cliente y Servicio de Excelencia</h4>
                      <p>Certificado - Vence: Septiembre 2025</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerfilTrabajador;
// ...existing code...
