import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import OrdenesAdmin from './components/OrdenesAdmin.jsx';
import PerfilAdmin from './components/PerfilAdmin.jsx';
import PerfilCliente from './components/PerfilCliente.jsx';
import PerfilTrabajador from './components/PerfilTrabajador.jsx';


import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<OrdenesAdmin />} />
        <Route path="/ordenes-admin" element={<OrdenesAdmin />} />
        
        {/* Rutas de OrdenesEmpleado ELIMINADAS */}
        
        {/* Rutas Comentadas: Actívalas cuando verifiques que existen */}
        {/* <Route path="/perfil-admin" element={<PerfilAdmin />} /> */}
        {/* <Route path="/perfil-cliente" element={<PerfilCliente />} /> */}
        {/* <Route path="/perfil-trabajador" element={<PerfilTrabajador />} /> */}
      </Routes>
    </Router>
  );
}

export default App;