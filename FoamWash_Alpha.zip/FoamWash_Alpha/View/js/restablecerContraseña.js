document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('recoveryForm');
    const emailInput = document.getElementById('email');
    const messageDisplay = document.getElementById('message');

    // Función para mostrar mensajes de estado
    function showMessage(text, type) {
        messageDisplay.textContent = text;
        messageDisplay.className = `message ${type}`;
        messageDisplay.style.display = 'block';

        // Ocultar el mensaje después de 5 segundos
        setTimeout(() => {
            messageDisplay.style.display = 'none';
        }, 5000);
    }

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Detener el envío del formulario por defecto
        
        const email = emailInput.value.trim();

        if (!email) {
            showMessage("Por favor, ingresa un correo electrónico válido.", 'error');
            return;
        }
        
        // Simulación del proceso de envío de instrucciones
        
        // Deshabilitar el formulario temporalmente
        const submitButton = form.querySelector('button');
        submitButton.disabled = true;
        submitButton.textContent = 'Enviando...';
        
        // Simular una espera de 2 segundos (como si fuera una llamada al servidor)
        setTimeout(() => {
            // Ejemplo de lógica de simulación:
            if (email === "error@foamwash.com") {
                // Simulación de un correo no encontrado o error del servidor
                showMessage("❌ Lo sentimos, no pudimos encontrar esa dirección de correo.", 'error');
            } else {
                // Simulación de envío exitoso
                showMessage(`✅ Se han enviado instrucciones de recuperación a ${email}. Revisa tu bandeja de entrada.`, 'success');
                // Opcional: Limpiar el campo de email
                emailInput.value = '';
            }
            
            // Habilitar el formulario de nuevo
            submitButton.disabled = false;
            submitButton.textContent = 'Enviar Instrucciones';

        }, 2000);
    });
});