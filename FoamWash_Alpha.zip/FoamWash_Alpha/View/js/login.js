// =============================================================================
// MANEJADOR DE PÁGINA DE LOGIN - FoamWash
// =============================================================================

// Verificar si ya hay una sesión activa
window.addEventListener('DOMContentLoaded', () => {
    if (Auth.isAuthenticated()) {
        const user = Auth.getCurrentUser();
        console.log('Usuario ya autenticado:', user.email);
        // Redirigir según el rol
        window.location.href = user.redirect;
    }
});

// =============================================================================
// FUNCIONES DE UI
// =============================================================================

// Mostrar mensajes en los formularios
function displayMessage(messageId, message, isError = false) {
    let messageElement = document.getElementById(messageId);
    
    // Si no existe el elemento, crearlo
    if (!messageElement) {
        const form = document.getElementById(messageId.replace('Message', 'Form'));
        if (form) {
            messageElement = document.createElement('div');
            messageElement.id = messageId;
            messageElement.className = 'message-area';
            form.appendChild(messageElement);
        }
    }

    if (messageElement) {
        messageElement.textContent = message;
        messageElement.className = 'message-area';
        
        if (message) {
            messageElement.classList.add(isError ? 'error-message' : 'success-message');
            messageElement.style.display = 'block';
        } else {
            messageElement.style.display = 'none';
        }
    }
}

// Deshabilitar formulario durante el proceso
function setFormDisabled(formId, disabled) {
    const form = document.getElementById(formId);
    if (form) {
        const inputs = form.querySelectorAll('input, button');
        inputs.forEach(input => {
            input.disabled = disabled;
        });
    }
}

// =============================================================================
// MANEJO DEL FORMULARIO DE LOGIN
// =============================================================================

const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        // Limpiar mensajes anteriores
        displayMessage('loginMessage', '');
        
        // Obtener valores
        const emailInput = loginForm.querySelector('input[type="email"]');
        const passwordInput = loginForm.querySelector('input[type="password"]');
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        // Validación básica
        if (!email || !password) {
            displayMessage('loginMessage', 'Por favor, completa todos los campos.', true);
            return;
        }

        // Deshabilitar formulario
        setFormDisabled('loginForm', true);

        try {
            // Intentar iniciar sesión
            const result = Auth.login(email, password);

            if (result.success) {
                displayMessage('loginMessage', result.message, false);
                
                console.log('✅ Login exitoso:', result.data.email, '-', result.data.role);
                
                // Redirigir después de 1 segundo
                setTimeout(() => {
                    window.location.href = result.data.redirect;
                }, 1000);
            } else {
                displayMessage('loginMessage', result.message, true);
                setFormDisabled('loginForm', false);
            }
        } catch (error) {
            console.error('Error en login:', error);
            displayMessage('loginMessage', 'Error al iniciar sesión. Intenta nuevamente.', true);
            setFormDisabled('loginForm', false);
        }
    });
}

// =============================================================================
// MANEJO DEL FORMULARIO DE REGISTRO
// =============================================================================

const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        // Limpiar mensajes anteriores
        displayMessage('registerMessage', '');
        
        // Obtener valores
        const inputs = registerForm.querySelectorAll('input');
        const email = inputs[0].value.trim();
        const fullName = inputs[1].value.trim();
        const phone = inputs[2].value.trim();
        const address = inputs[3].value.trim();
        const password = inputs[4].value.trim();

        // Validación básica
        if (!email || !fullName || !phone || !password) {
            displayMessage('registerMessage', 'Por favor, completa todos los campos obligatorios (*).', true);
            return;
        }

        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            displayMessage('registerMessage', 'Por favor, ingresa un correo electrónico válido.', true);
            return;
        }

        // Deshabilitar formulario
        setFormDisabled('registerForm', true);

        try {
            // Intentar registrar
            const result = Auth.register({
                email: email,
                password: password,
                fullName: fullName,
                phone: phone,
                address: address
            });

            if (result.success) {
                displayMessage('registerMessage', 'Registro exitoso. Redireccionando...', false);
                
                console.log('✅ Registro exitoso:', result.data.email);
                
                // Limpiar formulario
                registerForm.reset();
                
                // Redirigir después de 1 segundo
                setTimeout(() => {
                    window.location.href = result.data.redirect;
                }, 1000);
            } else {
                displayMessage('registerMessage', result.message, true);
                setFormDisabled('registerForm', false);
            }
        } catch (error) {
            console.error('Error en registro:', error);
            displayMessage('registerMessage', 'Error al registrar. Intenta nuevamente.', true);
            setFormDisabled('registerForm', false);
        }
    });
}

// =============================================================================
// LÓGICA DE INTERFAZ: SWITCH ENTRE LOGIN Y REGISTER
// =============================================================================

function setupToggleButtons() {
    const cardWrapper = document.querySelector('.card-wrapper');
    const switchToRegisterBtn = document.getElementById('switchToRegister');
    const switchToLoginBtn = document.getElementById('switchToLogin');

    if (switchToRegisterBtn && cardWrapper) {
        switchToRegisterBtn.addEventListener('click', (e) => {
            e.preventDefault();
            cardWrapper.classList.add('register-active');
            // Limpiar mensajes al cambiar
            displayMessage('loginMessage', '');
            displayMessage('registerMessage', '');
        });
    }

    if (switchToLoginBtn && cardWrapper) {
        switchToLoginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            cardWrapper.classList.remove('register-active');
            // Limpiar mensajes al cambiar
            displayMessage('loginMessage', '');
            displayMessage('registerMessage', '');
        });
    }
}

// =============================================================================
// MANEJO DE "OLVIDASTE TU CONTRASEÑA"
// =============================================================================

const forgotPasswordLink = document.querySelector('.forgot-link');
if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', (e) => {
        e.preventDefault();
        alert('Funcionalidad de recuperación de contraseña no implementada.\n\nUsuarios de prueba:\n- admin@gmail.com (123456)\n- trabajador@gmail.com (123456)\n- cliente@gmail.com (123456)');
    });
}

// =============================================================================
// INICIALIZACIÓN
// =============================================================================

setupToggleButtons();

console.log('📝 Página de login lista');
console.log('👥 Usuarios de prueba:');
console.log('   - admin@gmail.com / 123456');
console.log('   - trabajador@gmail.com / 123456');
console.log('   - cliente@gmail.com / 123456');