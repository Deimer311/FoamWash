 const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const imagePreview = document.getElementById('imagePreview');
        const previewContainer = document.getElementById('previewContainer');
        const changePhotoBtn = document.getElementById('changePhotoBtn');
        const profileForm = document.getElementById('profileForm');
        const successMessage = document.getElementById('successMessage');
        const currentPhoto = document.getElementById('currentPhoto');

        uploadArea.addEventListener('click', function(e) {
            if (!e.target.classList.contains('change-photo-btn')) {
                fileInput.click();
            }
        });

        changePhotoBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            fileInput.click();
        });

        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imageUrl = e.target.result;
                    imagePreview.src = imageUrl;
                    previewContainer.classList.add('active');
                    uploadArea.classList.add('has-image');
                    document.querySelector('.upload-placeholder').style.display = 'none';
                    document.querySelector('.upload-hint').style.display = 'none';
                    
                    currentPhoto.style.backgroundImage = `url(${imageUrl})`;
                    currentPhoto.style.backgroundSize = 'cover';
                    currentPhoto.style.backgroundPosition = 'center';
                    currentPhoto.textContent = '';
                };
                reader.readAsDataURL(file);
            }
        });

        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const passwordNueva = document.getElementById('passwordNueva').value;
            const passwordConfirmar = document.getElementById('passwordConfirmar').value;
            
            if (passwordNueva && passwordNueva !== passwordConfirmar) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            successMessage.classList.add('active');
            
            setTimeout(() => {
                successMessage.classList.remove('active');
            }, 3000);
        });

        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'translateX(3px)';
                this.parentElement.style.transition = 'transform 0.3s ease';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'translateX(0)';
            });
        });