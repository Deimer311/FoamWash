 const cards = document.querySelectorAll('.detail-card');
        cards.forEach((card, index) => {
            card.style.animation = `fadeIn 0.6s ease-out ${index * 0.1}s forwards`;
            card.style.opacity = '0';
        });