
        // Animación de números contadores
        function animateValue(id, start, end, duration) {
            const obj = document.getElementById(id);
            const range = end - start;
            const increment = end > start ? 1 : -1;
            const stepTime = Math.abs(Math.floor(duration / range));
            let current = start;
            const timer = setInterval(() => {
                current += increment;
                obj.textContent = current;
                if (current === end) {
                    clearInterval(timer);
                }
            }, stepTime);
        }

        // Inicializar contadores
        window.addEventListener('load', () => {
            animateValue('stat-hoy', 0, 1, 800);
            animateValue('stat-semana', 0, 2, 1000);
            animateValue('stat-completados', 0, 3, 1200);
            animateValue('stat-pendientes', 0, 3, 1400);
        });

        // Función de búsqueda
        function searchOrders() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const cards = document.querySelectorAll('.order-card');
            
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                if (text.includes(input)) {
                    card.style.display = 'block';
                    card.style.animation = 'fadeIn 0.5s ease';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Filtrar órdenes por categoría
        function filterOrders(category) {
            const sections = document.querySelectorAll('.section');
            
            sections.forEach(section => {
                section.style.display = 'none';
            });
            
            if (category === 'hoy') {
                document.getElementById('section-hoy').style.display = 'block';
            } else if (category === 'semana') {
                document.getElementById('section-semana').style.display = 'block';
            } else if (category === 'completados') {
                document.getElementById('section-completados').style.display = 'block';
            } else if (category === 'pendientes') {
                document.getElementById('section-hoy').style.display = 'block';
                document.getElementById('section-semana').style.display = 'block';
            }

            // Scroll suave a la sección
            setTimeout(() => {
                window.scrollTo({
                    top: 400,
                    behavior: 'smooth'
                });
            }, 100);
        }

        // Efecto parallax en scroll
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const cards = document.querySelectorAll('.order-card');
            
            cards.forEach((card, index) => {
                const speed = 0.5 + (index * 0.1);
                card.style.transform = `translateY(${scrolled * speed * 0.01}px)`;
            });
        });

        // Click en tarjetas
        document.querySelectorAll('.order-card').forEach(card => {
            card.addEventListener('click', function() {
                this.style.animation = 'pulse 0.5s ease';
                setTimeout(() => {
                    this.style.animation = '';
                }, 500);
            });
        });
   