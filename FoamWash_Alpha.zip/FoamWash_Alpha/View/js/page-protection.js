// =============================================================================
// EJEMPLOS DE PROTECCIÓN DE PÁGINAS - FoamWash
// =============================================================================

// ==================== PARA PÁGINAS DE ADMIN (reportes.html) ====================
/*
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reportes - Admin</title>
    <script src="./js/auth.js"></script>
</head>
<body>
    <script>
        // Proteger la página - solo admin puede acceder
        Auth.requireAuth(['admin']);
        
        // Obtener datos del usuario
        const currentUser = Auth.getCurrentUser();
        console.log('Usuario actual:', currentUser.name);
    </script>
    
    <h1>Bienvenido, <span id="userName"></span></h1>
    <button id="logoutBtn">Cerrar Sesión</button>
    
    <script>
        // Mostrar nombre del usuario
        document.getElementById('userName').textContent = currentUser.name;
        
        // Botón de cerrar sesión
        document.getElementById('logoutBtn').addEventListener('click', () => {
            if (confirm('¿Estás seguro de cerrar sesión?')) {
                Auth.logout();
            }
        });
        
        // Ver sesiones activas (solo admin)
        const activeSessions = Auth.getActiveSessions();
        console.log('Sesiones activas:', activeSessions);
    </script>
</body>
</html>
*/

// ==================== PARA PÁGINAS DE TRABAJADOR (tareas.html) ====================
/*
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tareas - Trabajador</title>
    <script src="./js/auth.js"></script>
</head>
<body>
    <script>
        // Proteger la página - solo trabajador puede acceder
        Auth.requireAuth(['trabajador']);
        
        const currentUser = Auth.getCurrentUser();
    </script>
    
    <h1>Mis Tareas - <span id="userName"></span></h1>
    <button id="logoutBtn">Cerrar Sesión</button>
    
    <script>
        document.getElementById('userName').textContent = currentUser.name;
        
        document.getElementById('logoutBtn').addEventListener('click', () => {
            Auth.logout();
        });
    </script>
</body>
</html>
*/

// ==================== PARA PÁGINAS DE CLIENTE (servicios_cliente.html) ====================
/*
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Servicios - Cliente</title>
    <script src="./js/auth.js"></script>
</head>
<body>
    <script>
        // Proteger la página - solo cliente puede acceder
        Auth.requireAuth(['cliente']);
        
        const currentUser = Auth.getCurrentUser();
    </script>
    
    <h1>Bienvenido, <span id="userName"></span></h1>
    <p>Email: <span id="userEmail"></span></p>
    <button id="logoutBtn">Cerrar Sesión</button>
    
    <script>
        document.getElementById('userName').textContent = currentUser.name;
        document.getElementById('userEmail').textContent = currentUser.email;
        
        document.getElementById('logoutBtn').addEventListener('click', () => {
            Auth.logout();
        });
    </script>
</body>
</html>
*/

// ==================== PARA PÁGINAS PÚBLICAS CON OPCIONES ====================
/*
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Página Pública</title>
    <script src="./js/auth.js"></script>
</head>
<body>
    <div id="userSection"></div>
    
    <script>
        // Verificar si hay sesión activa (sin obligarla)
        if (Auth.isAuthenticated()) {
            const user = Auth.getCurrentUser();
            document.getElementById('userSection').innerHTML = `
                <p>Bienvenido, ${user.name}</p>
                <button onclick="Auth.logout()">Cerrar Sesión</button>
            `;
        } else {
            document.getElementById('userSection').innerHTML = `
                <a href="./login.html">Iniciar Sesión</a>
            `;
        }
    </script>
</body>
</html>
*/

// ==================== PARA PÁGINAS CON MÚLTIPLES ROLES ====================
/*
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel General</title>
    <script src="./js/auth.js"></script>
</head>
<body>
    <script>
        // Proteger - admin Y trabajador pueden acceder
        Auth.requireAuth(['admin', 'trabajador']);
        
        const currentUser = Auth.getCurrentUser();
    </script>
    
    <h1>Panel de Control</h1>
    
    <div id="adminSection" style="display: none;">
        <h2>Sección de Administrador</h2>
        <p>Solo visible para admin</p>
    </div>
    
    <div id="workerSection" style="display: none;">
        <h2>Sección de Trabajador</h2>
        <p>Solo visible para trabajador</p>
    </div>
    
    <button onclick="Auth.logout()">Cerrar Sesión</button>
    
    <script>
        // Mostrar secciones según el rol
        if (Auth.hasRole('admin')) {
            document.getElementById('adminSection').style.display = 'block';
        }
        
        if (Auth.hasRole('trabajador')) {
            document.getElementById('workerSection').style.display = 'block';
        }
    </script>
</body>
</html>
*/

// =============================================================================
// FUNCIONES ÚTILES PARA USAR EN CUALQUIER PÁGINA
// =============================================================================

// Función para crear un navbar con información del usuario
function createUserNavbar() {
    if (!Auth.isAuthenticated()) return '';
    
    const user = Auth.getCurrentUser();
    
    return `
        <nav class="user-navbar">
            <div class="user-info">
                <span class="user-name">${user.name}</span>
                <span class="user-role">(${user.role})</span>
            </div>
            <button onclick="Auth.logout()" class="logout-btn">
                Cerrar Sesión
            </button>
        </nav>
    `;
}

// Función para mostrar información del usuario en consola
function logUserInfo() {
    if (!Auth.isAuthenticated()) {
        console.log('❌ No hay usuario autenticado');
        return;
    }
    
    const user = Auth.getCurrentUser();
    console.log('👤 Usuario actual:');
    console.log('   Email:', user.email);
    console.log('   Nombre:', user.name);
    console.log('   Rol:', user.role);
    console.log('   Token:', user.token);
    console.log('   Login:', new Date(user.loginTime).toLocaleString());
    console.log('   Última actividad:', new Date(user.lastActivity).toLocaleString());
    console.log('   Expira:', new Date(user.expiresAt).toLocaleString());
}

// Función para verificar permisos antes de una acción
function checkPermission(requiredRole, action) {
    if (!Auth.hasRole(requiredRole)) {
        alert(`No tienes permisos para ${action}. Se requiere rol: ${requiredRole}`);
        return false;
    }
    return true;
}

// Ejemplo de uso de checkPermission:
// if (checkPermission('admin', 'eliminar usuarios')) {
//     // Código para eliminar usuario
// }

// Función para redireccionar según el rol
function redirectByRole() {
    if (!Auth.isAuthenticated()) {
        window.location.href = './login.html';
        return;
    }
    
    const user = Auth.getCurrentUser();
    window.location.href = user.redirect;
}

// Función para obtener el token (útil para peticiones API)
function getAuthToken() {
    const user = Auth.getCurrentUser();
    return user ? user.token : null;
}

// Función para hacer peticiones autenticadas (ejemplo)
async function authenticatedFetch(url, options = {}) {
    const token = getAuthToken();
    
    if (!token) {
        throw new Error('No hay sesión activa');
    }
    
    // Agregar token en headers
    options.headers = {
        ...options.headers,
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    };
    
    try {
        const response = await fetch(url, options);
        
        // Si recibe 401, la sesión expiró
        if (response.status === 401) {
            alert('Tu sesión ha expirado');
            Auth.logout();
            throw new Error('Sesión expirada');
        }
        
        return response;
    } catch (error) {
        console.error('Error en petición autenticada:', error);
        throw error;
    }
}

// =============================================================================
// EXPORTAR FUNCIONES ÚTILES
// =============================================================================

if (typeof window !== 'undefined') {
    window.AuthHelpers = {
        createUserNavbar,
        logUserInfo,
        checkPermission,
        redirectByRole,
        getAuthToken,
        authenticatedFetch
    };
}

console.log('🛡️ Utilidades de autenticación cargadas');