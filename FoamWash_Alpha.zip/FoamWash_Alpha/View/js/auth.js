// =============================================================================
// SISTEMA DE AUTENTICACIÓN CON TOKENS - FoamWash
// =============================================================================

// Base de datos simulada de usuarios
const USERS_DB = {
    "admin@gmail.com": { 
        password: "123456", 
        role: "admin", 
        name: "Administrador",
        redirect: "./Perfiladmin.html" 
    },
    "trabajador@gmail.com": { 
        password: "123456", 
        role: "trabajador",
        name: "Trabajador",
        redirect: "./Perfiltrabajador.html" 
    },
    "cliente@gmail.com": { 
        password: "123456", 
        role: "cliente",
        name: "Cliente",
        redirect: "./servicios_cliente.html" 
    }
};

// Configuración de tiempo de expiración (en milisegundos)
const SESSION_TIMEOUT = 2 * 60 * 60 * 1000; // 2 horas
const ACTIVITY_CHECK_INTERVAL = 60 * 1000; // Verificar cada minuto

// =============================================================================
// CLASE PRINCIPAL DE AUTENTICACIÓN
// =============================================================================

class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.activityInterval = null;
        this.init();
    }

    // Inicializar el sistema
    init() {
        this.loadSession();
        this.setupActivityMonitoring();
        this.cleanExpiredSessions();
    }

    // Generar token único
    generateToken() {
        return `token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    // Cifrar contraseña (simulación simple)
    hashPassword(password) {
        // En producción usa bcrypt o similar
        return btoa(password + 'salt-foamwash');
    }

    // Validar credenciales
    validateCredentials(email, password) {
        const user = USERS_DB[email];
        if (!user) return null;
        if (user.password !== password) return null;
        return user;
    }

    // Iniciar sesión
    login(email, password) {
        const user = this.validateCredentials(email, password);
        
        if (!user) {
            return {
                success: false,
                message: "Correo o contraseña incorrectos."
            };
        }

        const token = this.generateToken();
        const sessionData = {
            token: token,
            email: email,
            role: user.role,
            name: user.name,
            redirect: user.redirect,
            loginTime: new Date().toISOString(),
            lastActivity: new Date().toISOString(),
            expiresAt: new Date(Date.now() + SESSION_TIMEOUT).toISOString()
        };

        // Guardar en sessionStorage (sesión actual)
        this.saveSession(sessionData);

        // Registrar en localStorage (historial de sesiones activas)
        this.registerActiveSession(sessionData);

        this.currentUser = sessionData;

        return {
            success: true,
            message: `¡Bienvenido, ${user.name}!`,
            data: sessionData
        };
    }

    // Registrar nueva cuenta
    register(userData) {
        const { email, password, fullName, phone, address } = userData;

        // Validaciones
        if (USERS_DB[email]) {
            return {
                success: false,
                message: "El correo electrónico ya está registrado."
            };
        }

        if (password.length < 6) {
            return {
                success: false,
                message: "La contraseña debe tener al menos 6 caracteres."
            };
        }

        if (!/^\d{10}$/.test(phone)) {
            return {
                success: false,
                message: "El teléfono debe tener 10 dígitos."
            };
        }

        // Crear nuevo usuario
        const newUser = {
            password: password,
            role: "cliente",
            name: fullName,
            phone: phone,
            address: address || "",
            redirect: "./servicios_cliente.html",
            createdAt: new Date().toISOString()
        };

        USERS_DB[email] = newUser;

        // Guardar usuarios registrados en localStorage
        this.saveUsersDB();

        // Iniciar sesión automáticamente
        return this.login(email, password);
    }

    // Guardar sesión actual
    saveSession(sessionData) {
        sessionStorage.setItem('authToken', sessionData.token);
        sessionStorage.setItem('userRole', sessionData.role);
        sessionStorage.setItem('userEmail', sessionData.email);
        sessionStorage.setItem('userName', sessionData.name);
        sessionStorage.setItem('sessionData', JSON.stringify(sessionData));
    }

    // Cargar sesión actual
    loadSession() {
        try {
            const sessionData = sessionStorage.getItem('sessionData');
            if (!sessionData) return null;

            const data = JSON.parse(sessionData);
            
            // Verificar si la sesión ha expirado
            if (this.isSessionExpired(data)) {
                this.logout();
                return null;
            }

            this.currentUser = data;
            this.updateActivity();
            return data;
        } catch (error) {
            console.error('Error al cargar sesión:', error);
            return null;
        }
    }

    // Verificar si la sesión ha expirado
    isSessionExpired(sessionData) {
        if (!sessionData.expiresAt) return true;
        return new Date() > new Date(sessionData.expiresAt);
    }

    // Actualizar última actividad
    updateActivity() {
        if (!this.currentUser) return;

        this.currentUser.lastActivity = new Date().toISOString();
        this.currentUser.expiresAt = new Date(Date.now() + SESSION_TIMEOUT).toISOString();
        
        sessionStorage.setItem('sessionData', JSON.stringify(this.currentUser));
        
        // Actualizar en sesiones activas
        this.updateActiveSession(this.currentUser.token);
    }

    // Configurar monitoreo de actividad
    setupActivityMonitoring() {
        // Actualizar actividad en cada interacción
        ['click', 'keypress', 'scroll', 'mousemove'].forEach(event => {
            document.addEventListener(event, () => {
                if (this.currentUser) {
                    this.updateActivity();
                }
            }, { passive: true, once: false });
        });

        // Verificar expiración periódicamente
        this.activityInterval = setInterval(() => {
            const session = this.loadSession();
            if (session && this.isSessionExpired(session)) {
                alert('Tu sesión ha expirado. Por favor, inicia sesión nuevamente.');
                this.logout();
            }
        }, ACTIVITY_CHECK_INTERVAL);
    }

    // Registrar sesión activa en el sistema
    registerActiveSession(sessionData) {
        let activeSessions = JSON.parse(localStorage.getItem('sesionesActivas') || '[]');
        
        // Remover sesiones anteriores del mismo usuario
        activeSessions = activeSessions.filter(s => s.email !== sessionData.email);
        
        // Agregar nueva sesión
        activeSessions.push({
            id: `SESSION-${Date.now()}`,
            token: sessionData.token,
            email: sessionData.email,
            role: sessionData.role,
            name: sessionData.name,
            loginTime: sessionData.loginTime,
            lastActivity: sessionData.lastActivity,
            expiresAt: sessionData.expiresAt
        });

        localStorage.setItem('sesionesActivas', JSON.stringify(activeSessions));
    }

    // Actualizar sesión activa
    updateActiveSession(token) {
        let activeSessions = JSON.parse(localStorage.getItem('sesionesActivas') || '[]');
        
        const session = activeSessions.find(s => s.token === token);
        if (session) {
            session.lastActivity = new Date().toISOString();
            session.expiresAt = new Date(Date.now() + SESSION_TIMEOUT).toISOString();
            localStorage.setItem('sesionesActivas', JSON.stringify(activeSessions));
        }
    }

    // Eliminar sesión activa
    removeActiveSession(token) {
        let activeSessions = JSON.parse(localStorage.getItem('sesionesActivas') || '[]');
        activeSessions = activeSessions.filter(s => s.token !== token);
        localStorage.setItem('sesionesActivas', JSON.stringify(activeSessions));
    }

    // Limpiar sesiones expiradas
    cleanExpiredSessions() {
        let activeSessions = JSON.parse(localStorage.getItem('sesionesActivas') || '[]');
        const now = new Date();
        
        const validSessions = activeSessions.filter(session => {
            return new Date(session.expiresAt) > now;
        });

        const removed = activeSessions.length - validSessions.length;
        if (removed > 0) {
            console.log(`🧹 ${removed} sesiones expiradas eliminadas`);
        }

        localStorage.setItem('sesionesActivas', JSON.stringify(validSessions));
    }

    // Cerrar sesión
    logout() {
        if (this.currentUser) {
            this.removeActiveSession(this.currentUser.token);
        }

        // Limpiar sessionStorage
        sessionStorage.clear();

        // Detener monitoreo de actividad
        if (this.activityInterval) {
            clearInterval(this.activityInterval);
        }

        this.currentUser = null;

        // Redirigir al login
        window.location.href = './login.html';
    }

    // Verificar autenticación
    isAuthenticated() {
        if (!this.currentUser) {
            this.loadSession();
        }
        return this.currentUser !== null;
    }

    // Obtener usuario actual
    getCurrentUser() {
        if (!this.currentUser) {
            this.loadSession();
        }
        return this.currentUser;
    }

    // Verificar rol
    hasRole(allowedRoles) {
        if (!Array.isArray(allowedRoles)) {
            allowedRoles = [allowedRoles];
        }
        
        const user = this.getCurrentUser();
        if (!user) return false;
        
        return allowedRoles.includes(user.role);
    }

    // Proteger página
    requireAuth(allowedRoles = []) {
        if (!this.isAuthenticated()) {
            alert('Debes iniciar sesión para acceder a esta página.');
            window.location.href = './login.html';
            return false;
        }

        if (allowedRoles.length > 0 && !this.hasRole(allowedRoles)) {
            alert('No tienes permisos para acceder a esta página.');
            this.logout();
            return false;
        }

        return true;
    }

    // Guardar base de datos de usuarios
    saveUsersDB() {
        try {
            localStorage.setItem('usersDB', JSON.stringify(USERS_DB));
        } catch (error) {
            console.error('Error al guardar usuarios:', error);
        }
    }

    // Cargar base de datos de usuarios
    loadUsersDB() {
        try {
            const savedUsers = localStorage.getItem('usersDB');
            if (savedUsers) {
                Object.assign(USERS_DB, JSON.parse(savedUsers));
            }
        } catch (error) {
            console.error('Error al cargar usuarios:', error);
        }
    }

    // Obtener todas las sesiones activas (solo para admin)
    getActiveSessions() {
        const user = this.getCurrentUser();
        if (!user || user.role !== 'admin') {
            return [];
        }
        
        this.cleanExpiredSessions();
        return JSON.parse(localStorage.getItem('sesionesActivas') || '[]');
    }
}

// =============================================================================
// INSTANCIA GLOBAL
// =============================================================================

// Crear instancia única del sistema de autenticación
const Auth = new AuthSystem();

// Exportar para uso en otros archivos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Auth;
}

console.log('🔐 Sistema de autenticación inicializado');