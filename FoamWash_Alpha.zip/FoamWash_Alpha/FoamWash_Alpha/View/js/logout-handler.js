// ============================================
// logout-handler.js
// ============================================
// Script universal para manejar cierre de sesión

(function() {
    'use strict';

    // ⭐ Función principal de logout
    window.cerrarSesionCliente = function(e) {
        if (e) e.preventDefault();
        
        if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
            console.log('🚪 Cerrando sesión...');
            
            // Limpiar TODOS los datos de sesión
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            localStorage.removeItem('authToken');
            localStorage.removeItem('userRole');
            localStorage.removeItem('userEmail');
            localStorage.removeItem('userName');
            localStorage.removeItem('sessionData');
            sessionStorage.clear();
            
            // Mostrar mensaje
            alert('Sesión cerrada correctamente');
            
            // Redirigir al login
            setTimeout(() => {
                window.location.href = './index.html';
            }, 500);
        }
    };

    // Alias para compatibilidad
    window.logout = window.cerrarSesionCliente;

    // ⭐ Proteger páginas automáticamente
    window.protectPage = function(allowedRoles = []) {
        const token = localStorage.getItem('token');
        const user = localStorage.getItem('user');
        
        if (!token || !user) {
            alert('Debes iniciar sesión para acceder a esta página.');
            window.location.href = './index.html';
            return null;
        }
        
        try {
            return JSON.parse(user);
        } catch (e) {
            console.error('Error al parsear usuario:', e);
            window.location.href = './index.html';
            return null;
        }
    };

    // ⭐ Mostrar email del usuario en el header automáticamente
    window.addEventListener('DOMContentLoaded', () => {
        const token = localStorage.getItem('token');
        const userStr = localStorage.getItem('user');
        
        if (token && userStr) {
            try {
                const user = JSON.parse(userStr);
                
                // Buscar elementos donde mostrar el email
                const userEmailElements = document.querySelectorAll('[data-user-email]');
                userEmailElements.forEach(el => {
                    el.textContent = `👤 ${user.email || user.username}`;
                });
                
                console.log('✅ Usuario autenticado:', user.email || user.username);
            } catch (e) {
                console.error('Error al cargar usuario:', e);
            }
        }
    });

    console.log('🔐 Logout handler inicializado');
})();