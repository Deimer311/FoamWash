// src/reservas/reservas.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ReservasService {
  constructor(private prisma: PrismaService) {}

  // GET /api/reservas
  async findAll() {
    return this.prisma.reserva.findMany({
      include: {
        cliente: { select: { Nombre: true, Telefono: true, Correo: true } },
        observacion: { select: { Observaciones: true, estado: true } },
        empleado: { select: { Nombre: true } },
        servicios: true,
      },
      orderBy: [{ fecha: 'desc' }],
    });
  }

  // GET /api/reservas/estado/:estado
  async findByEstado(estado: string) {
    return this.prisma.reserva.findMany({
      where: { Estado: estado },
      include: {
        cliente: { select: { Nombre: true, Telefono: true } },
      },
      orderBy: [{ fecha: 'asc' }],
    });
  }

  // GET /api/reservas/:id
  async findOne(id: number) {
    const reserva = await this.prisma.reserva.findUnique({
      where: { ID_Reserva: id },
      include: {
        cliente: { select: { Nombre: true, Telefono: true, Correo: true } },
        empleado: { select: { Nombre: true } },
        servicios: true,
        observacion: true,
      },
    });
    if (!reserva) throw new NotFoundException('Reserva no encontrada');
    return reserva;
  }

  // POST /api/reservas
  async create(data: {
    Estado?: string;
    Id_Usuario: number;
    fecha?: Date;
    Hora?: string;
    Informacion_adicional?: string;
    observacion_Id_Observaciones?: number;
    empleado_Id_Usuario?: number;
  }) {
    return this.prisma.reserva.create({
      data: {
        Estado: data.Estado,
        fecha: data.fecha,
        Hora: data.Hora,
        Informacion_adicional: data.Informacion_adicional,
        cliente: { connect: { Id_Usuario: data.Id_Usuario } },
        empleado: data.empleado_Id_Usuario
          ? { connect: { Id_Usuario: data.empleado_Id_Usuario } }
          : undefined,
        observacion: data.observacion_Id_Observaciones
          ? { connect: { Id_Observaciones: data.observacion_Id_Observaciones } }
          : undefined,
      },
    });
  }

  // PUT /api/reservas/:id
  async update(
    id: number,
    data: Partial<{
      Estado: string;
      fecha: Date;
      Hora: string;
      Informacion_adicional: string;
      empleado_Id_Usuario: number;
    }>,
  ) {
    const exists = await this.prisma.reserva.findUnique({ where: { ID_Reserva: id } });
    if (!exists) throw new NotFoundException('Reserva no encontrada');
    return this.prisma.reserva.update({ where: { ID_Reserva: id }, data });
  }

  // PATCH /api/reservas/:id/estado
  async updateEstado(id: number, estado: string) {
    const exists = await this.prisma.reserva.findUnique({ where: { ID_Reserva: id } });
    if (!exists) throw new NotFoundException('Reserva no encontrada');
    return this.prisma.reserva.update({
      where: { ID_Reserva: id },
      data: { Estado: estado },
    });
  }

  // DELETE /api/reservas/:id
  async remove(id: number) {
    const exists = await this.prisma.reserva.findUnique({ where: { ID_Reserva: id } });
    if (!exists) throw new NotFoundException('Reserva no encontrada');
    return this.prisma.reserva.delete({ where: { ID_Reserva: id } });
  }

  // GET reservas por cliente
  async findByCliente(clienteId: number) {
    return this.prisma.reserva.findMany({
      where: { Id_Usuario: clienteId },
      include: { servicios: true, observacion: true },
      orderBy: { fecha: 'desc' },
    });
  }
}