// src/cotizaciones/cotizaciones.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CotizacionesService {
  constructor(private prisma: PrismaService) {}

  async getServicios() {
    return this.prisma.servicio.findMany({
      select: { Id_Servicio: true, Nombre_Servicio: true, Precio: true, descripcion: true, imagen_url: true },
      orderBy: { Nombre_Servicio: 'asc' },
    });
  }

  async findAll() {
    return this.prisma.cotizacion.findMany({
      include: {
        cliente: { select: { Nombre: true, Correo: true, Telefono: true } },
        servicios: true,
      },
      orderBy: { fecha_cotizacion: 'desc' },
    });
  }

  async create(data: { Precio_cotizado: number; Cantidad: number; Tamaño: string; Id_usuario: number; fecha_cotizacion?: Date }) {
    return this.prisma.cotizacion.create({ data });
  }

  async sincronizar(items: any[], userId: number) {
    const results = [];
    for (const item of items) {
      const existing = await this.prisma.cotizacion.findFirst({
        where: { Id_usuario: userId, servicios: { some: { Id_Servicio: item.servicioId } } },
      });
      if (!existing) {
        const created = await this.prisma.cotizacion.create({
          data: {
            Precio_cotizado: item.precio,
            Cantidad: item.cantidad || 1,
            Tamaño: item.tamaño || null,
            Id_usuario: userId,
            fecha_cotizacion: new Date(),
            servicios: { connect: { Id_Servicio: item.servicioId } },
          },
        });
        results.push(created);
      }
    }
    return results;
  }
}
